package com.pfizer.system.mapper;

import com.pfizer.common.core.mapper.BaseMapperPlus;
import com.pfizer.system.domain.SysOss;
import com.pfizer.system.domain.vo.SysOssVo;

/**
 * 文件上传 数据层
 *
 * @author Lion Li
 */
public interface SysOssMapper extends BaseMapperPlus<SysOssMapper, SysOss, SysOssVo> {
}
