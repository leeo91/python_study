package com.pfizer.demo.mapper;

import com.pfizer.common.core.mapper.BaseMapperPlus;
import com.pfizer.demo.domain.TestDemoEncrypt;

/**
 * 测试加密功能
 *
 * @author Lion Li
 */
public interface TestDemoEncryptMapper extends BaseMapperPlus<TestDemoEncryptMapper, TestDemoEncrypt, TestDemoEncrypt> {

}
