package com.ruoyi.common.core;

/**
 * 可生成 Int 数组的接口
 *
 * @author 芋道源码
 */
public interface IntArrayValuable {

    /**
     * @return int 数组
     */
    int[] array();

}
