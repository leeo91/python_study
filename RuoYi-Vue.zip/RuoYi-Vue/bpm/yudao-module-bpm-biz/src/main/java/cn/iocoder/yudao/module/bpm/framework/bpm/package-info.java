/**
 * 提供给 Activiti 和 Flowable 的通用封装
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.module.bpm.framework.bpm;
