/**
 * bpm 模块的 web 配置
 */
package cn.iocoder.yudao.module.bpm.framework.web;
