/**
 * 自定义 Event 实现，提供方便业务接入的 Listener！
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.module.bpm.framework.bpm.core.event;
