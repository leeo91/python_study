package cn.iocoder.yudao.module.bpm.dal.dataobject.definition;

// TODO 芋艿：先埋个坑。任务消息的配置规则。说白了，就是不同的
public class BpmTaskMessageRuleDO {
}
