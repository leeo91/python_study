/**
 * 属于 bpm 模块的 framework 封装
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.module.bpm.framework;
