/**
 * 提供 POJO 类的实体转换
 *
 * 目前使用 MapStruct 框架
 */
package cn.iocoder.yudao.module.bpm.convert;
